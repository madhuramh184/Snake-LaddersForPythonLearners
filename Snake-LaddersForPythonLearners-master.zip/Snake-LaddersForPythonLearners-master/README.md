# Snake-LaddersForPythonLearners
The project aims at helping learners to revise the concepts of the programming language they are learning. 
Use SnakesandLadders.py from demo file to run the game to get the learning experince.
The project makes use of pygame library.  
